/**
 * Checks if the given origin is in the allowed origins list.
 * Returns false for undefined origins.
 */
export declare function isOriginAllowed(origin: string | undefined): boolean;
/**
 * Returns CORS headers if the request origin is allowed.
 * If the origin is not allowed, returns an empty object.
 */
export declare function getCorsHeaders(requestOrigin: string | undefined): Record<string, string>;
//# sourceMappingURL=cors.d.ts.map