import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleGameMe(event: APIGatewayProxyEvent): Promise<LambdaResponse>;
//# sourceMappingURL=gameMe.d.ts.map