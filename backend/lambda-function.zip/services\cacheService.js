"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cacheService = void 0;
const redis_1 = require("redis");
const logger_1 = require("../utils/logger");
const CACHE_ENDPOINT = process.env.CACHE_ENDPOINT || 'localhost';
const CACHE_PORT = parseInt(process.env.CACHE_PORT || '6379', 10);
const CACHE_TLS = process.env.CACHE_TLS !== 'false'; // default true
const GAME_SESSION_TTL = parseInt(process.env.GAME_SESSION_TTL || '1800', 10); // 30 min
let client = null;
async function getClient() {
    if (client && client.isOpen) {
        return client;
    }
    client = (0, redis_1.createClient)({
        url: `redis${CACHE_TLS ? 's' : ''}://${CACHE_ENDPOINT}:${CACHE_PORT}`,
        socket: {
            tls: CACHE_TLS,
            reconnectStrategy: (retries) => {
                if (retries > 3)
                    return new Error('Max reconnect attempts reached');
                return Math.min(retries * 100, 1000);
            },
            connectTimeout: 5000,
        },
    });
    client.on('error', (err) => {
        (0, logger_1.logError)('Cache connection error', { error: err.message });
    });
    await client.connect();
    (0, logger_1.logSafe)('Cache connected', { endpoint: CACHE_ENDPOINT, port: String(CACHE_PORT) });
    return client;
}
exports.cacheService = {
    async ping() {
        try {
            const redis = await getClient();
            const result = await redis.ping();
            return result === 'PONG';
        }
        catch {
            return false;
        }
    },
    async createGameSession(sub) {
        const redis = await getClient();
        const key = `game:session:${sub}`;
        const session = {
            status: 'playing',
            score: '0',
            startedAt: new Date().toISOString(),
        };
        await redis.hSet(key, session);
        await redis.expire(key, GAME_SESSION_TTL);
        return { status: 'playing', score: 0, startedAt: session.startedAt };
    },
    async getGameSession(sub) {
        const redis = await getClient();
        const key = `game:session:${sub}`;
        const data = await redis.hGetAll(key);
        if (!data || !data.status)
            return null;
        return {
            status: data.status,
            score: parseInt(data.score || '0', 10),
            startedAt: data.startedAt || '',
        };
    },
    async endGameSession(sub, finalScore) {
        const redis = await getClient();
        const key = `game:session:${sub}`;
        await redis.hSet(key, { status: 'finished', score: String(finalScore) });
        await redis.expire(key, 60);
    },
    async updateRanking(sub, score) {
        const redis = await getClient();
        const key = 'ranking:global';
        const previousScore = await redis.zScore(key, sub);
        await redis.zAdd(key, { score, value: sub }, { GT: true });
        const currentScore = await redis.zScore(key, sub) || score;
        const rank = await redis.zRevRank(key, sub);
        const rankPosition = rank !== null ? rank + 1 : -1;
        return {
            newBest: previousScore === null || score > previousScore,
            bestScore: currentScore,
            rankPosition,
        };
    },
    async getTopRanking(limit) {
        const redis = await getClient();
        const results = await redis.zRangeWithScores('ranking:global', 0, limit - 1, { REV: true });
        const ranking = await Promise.all(results.map(async (entry, index) => {
            const playerData = await redis.hGetAll(`player:${entry.value}`);
            return {
                position: index + 1,
                username: playerData?.username || 'Jogador',
                score: entry.score,
            };
        }));
        return ranking;
    },
    async getPlayerInfo(sub) {
        const redis = await getClient();
        const playerData = await redis.hGetAll(`player:${sub}`);
        const bestScore = await redis.zScore('ranking:global', sub);
        return {
            username: playerData?.username || 'Jogador',
            bestScore: bestScore || 0,
        };
    },
    async setPlayerUsername(sub, username) {
        const redis = await getClient();
        await redis.hSet(`player:${sub}`, { username });
    },
};
//# sourceMappingURL=cacheService.js.map