"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const health_1 = require("./routes/health");
const me_1 = require("./routes/me");
const gameStatus_1 = require("./routes/gameStatus");
const gameStart_1 = require("./routes/gameStart");
const gameScore_1 = require("./routes/gameScore");
const gameRanking_1 = require("./routes/gameRanking");
const gameMe_1 = require("./routes/gameMe");
const response_1 = require("./utils/response");
const cors_1 = require("./utils/cors");
const logger_1 = require("./utils/logger");
const handler = async (event) => {
    const origin = event.headers?.origin || event.headers?.Origin;
    try {
        const { httpMethod, path } = event;
        // Handle OPTIONS preflight
        if (httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    ...(0, cors_1.getCorsHeaders)(origin),
                },
                body: '',
            };
        }
        // Route based on method + path
        if (httpMethod === 'GET') {
            switch (path) {
                case '/health':
                    return (0, health_1.handleHealth)(event);
                case '/me':
                    return (0, me_1.handleMe)(event);
                case '/game/status':
                    return await (0, gameStatus_1.handleGameStatus)(event);
                case '/game/ranking':
                    return await (0, gameRanking_1.handleGameRanking)(event);
                case '/game/me':
                    return await (0, gameMe_1.handleGameMe)(event);
            }
        }
        if (httpMethod === 'POST') {
            switch (path) {
                case '/game/start':
                    return await (0, gameStart_1.handleGameStart)(event);
                case '/game/score':
                    return await (0, gameScore_1.handleGameScore)(event);
            }
        }
        // 404 for unmatched routes
        return (0, response_1.buildErrorResponse)(404, 'Rota não encontrada', origin);
    }
    catch (error) {
        // Secure logging - no stack traces, no sensitive data
        (0, logger_1.logError)('Unhandled error', {
            path: event.path,
            method: event.httpMethod,
            errorType: error?.name ?? 'Unknown',
        });
        return (0, response_1.buildErrorResponse)(500, 'Erro interno do servidor', origin);
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map