import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleGameScore(event: APIGatewayProxyEvent): Promise<LambdaResponse>;
//# sourceMappingURL=gameScore.d.ts.map