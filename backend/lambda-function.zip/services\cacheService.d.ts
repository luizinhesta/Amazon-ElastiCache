export declare const cacheService: {
    ping(): Promise<boolean>;
    createGameSession(sub: string): Promise<{
        status: string;
        score: number;
        startedAt: string;
    }>;
    getGameSession(sub: string): Promise<{
        status: string;
        score: number;
        startedAt: string;
    } | null>;
    endGameSession(sub: string, finalScore: number): Promise<void>;
    updateRanking(sub: string, score: number): Promise<{
        newBest: boolean;
        bestScore: number;
        rankPosition: number;
    }>;
    getTopRanking(limit: number): Promise<Array<{
        position: number;
        username: string;
        score: number;
    }>>;
    getPlayerInfo(sub: string): Promise<{
        username: string;
        bestScore: number;
    } | null>;
    setPlayerUsername(sub: string, username: string): Promise<void>;
};
//# sourceMappingURL=cacheService.d.ts.map