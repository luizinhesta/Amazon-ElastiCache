import { LambdaResponse } from '../types';
export declare function buildResponse(statusCode: number, body: object, origin?: string): LambdaResponse;
export declare function buildErrorResponse(statusCode: number, message: string, origin?: string): LambdaResponse;
//# sourceMappingURL=response.d.ts.map