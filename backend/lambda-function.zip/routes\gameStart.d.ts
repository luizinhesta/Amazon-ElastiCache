import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleGameStart(event: APIGatewayProxyEvent): Promise<LambdaResponse>;
//# sourceMappingURL=gameStart.d.ts.map